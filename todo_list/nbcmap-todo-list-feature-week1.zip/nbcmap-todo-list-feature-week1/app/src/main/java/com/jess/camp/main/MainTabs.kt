package com.jess.camp.main

import androidx.fragment.app.Fragment

data class MainTabs(
    val fragment: Fragment,
    val titleRes: Int
)
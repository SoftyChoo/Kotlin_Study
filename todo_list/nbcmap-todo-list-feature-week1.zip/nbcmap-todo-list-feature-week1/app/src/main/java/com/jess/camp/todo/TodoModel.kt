package com.jess.camp.todo

data class TodoModel(
    val id: Int,
    val title: String
)
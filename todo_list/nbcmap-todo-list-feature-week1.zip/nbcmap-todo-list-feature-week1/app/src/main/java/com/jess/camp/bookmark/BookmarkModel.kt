package com.jess.camp.bookmark

data class BookmarkModel(
    val id: Int,
    val title: String
)
package com.jess.camp.bookmark

import androidx.lifecycle.ViewModel

class BookmarkViewModel : ViewModel() {

}